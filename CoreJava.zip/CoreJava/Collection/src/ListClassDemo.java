import java.util.ArrayList;
import java.util.LinkedList;

public class ListClassDemo
{
	public static void ArrayListDemo()
	{
		ArrayList<String>a=new ArrayList<>();
{
a.add("Souree");
a.add("sara");
a.add("rounak");
System.out.println(a);
String nameToBeSearch ="Souree";
System.out.println(a.contains(nameToBeSearch));
String nameToBeRemove ="Sara";
System.out.println(a.contains(nameToBeRemove));
for(String arrayList :a)
{
	System.out.println(arrayList);}
}
}
	public static void linkedListDemo()
	{
		LinkedList<String>a=new LinkedList<>();
{
a.add("Souree");
a.add("sara");
a.add("rounak");
System.out.println(a);
String nameToBeSearch ="Souree";
System.out.println(a.contains(nameToBeSearch));
String nameToBeRemove ="Sara";
System.out.println(a.contains(nameToBeRemove));
for(String linkedList :a)
{
	System.out.println(linkedList);}
}
}	
}