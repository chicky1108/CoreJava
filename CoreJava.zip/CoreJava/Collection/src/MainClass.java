import java.util.ArrayList;
import java.util.Collections;

public class MainClass {

	public static void main(String[] args) {
		ListClassDemo arrayList = new ListClassDemo();
		ListClassDemo linkedList = new ListClassDemo();
arrayList.ArrayListDemo();
		linkedList.linkedListDemo();
ArrayList<Associate>associate=new ArrayList<>();
associate.add(new Associate(1,"souree","biswas",80000));
associate.add(new Associate(2,"chudail","biswas",70000));
associate.add(new Associate(3,"rounak","das",90000));
System.out.println(associate);
Collections.sort(associate);
for(Associate a:associate)
{
	System.out.println(a);
	}
System.out.println("=================");
Collections.sort(associate,new AssociateComparator());
for(Associate a:associate) {
	System.out.println(a);
}
	}

}
