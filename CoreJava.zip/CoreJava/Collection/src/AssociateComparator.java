import java.util.Comparator;

public class AssociateComparator implements Comparator <Associate>
{

	@Override
	public int compare(Associate o1, Associate o2) {
		// TODO Auto-generated method stub
		return o1.getSalary()-o2.getSalary();
	}
}


