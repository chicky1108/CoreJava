import java.util.HashSet;

public class SetClassDemo {

	
	public static void hashSetClassDemo() 
	{
		HashSet<Associate>associates=new HashSet<>();
		associates.add(new Associate(111,"souree","das",30000));
		associates.add(new Associate(112,"ree","das",3000));
		associates.add(new Associate(113,"sou","das",300));
		associates.add(new Associate(114,"sour","das",30));
		associates.add(new Associate(115,"soure","das",3));
		
		Associate nameToBeRemove=new Associate(111,"souree","das",30000);
		System.out.println(associates.remove(nameToBeRemove));
		
		
		
		// TODO Auto-generated method stub

	}

}
