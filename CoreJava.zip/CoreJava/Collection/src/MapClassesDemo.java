import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Set;

public class MapClassesDemo
{
public static void hashMapDemo()
{
	Hashtable<Integer,Associate>associates=new Hashtable<>();
	associates.put(111,new Associate(111,"sbs","das",15));
	associates.put(112,new Associate(112,"sb","das",15000));
	associates.put(113,new Associate(113,"sbp","das",150));
	associates.put(114,new Associate(114,"sbc","das",1500));
	associates.put(112,new Associate(114,"sb","das",15000));
	
	Associate associate = associate.get(112);
	associates.remove(112);
	Set<Integer>keys = associates.keySet();
	
	for(Integer key:keys)
	{
		System.out.println(associates.get(key));
		
	}
	ArrayList<Associate>associateList= new ArrayList<>(associates.values());
}
}
