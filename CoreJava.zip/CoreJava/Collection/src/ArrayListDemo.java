import java.util.ArrayList;
public class ArrayListDemo 
{
	public static void ArrayListDemo()
	{
ArrayList<String>a=new ArrayList<>();
{
a.add("Souree");
a.add("sara");
a.add("rounak");
System.out.println(a);
String nameToBeSearch ="Souree";
System.out.println(a.contains(nameToBeSearch));
String nameToBeRemove ="Sara";
System.out.println(a.contains(nameToBeRemove));
for(String arrayList :a)
{
	System.out.println(arrayList);}
}
}
}