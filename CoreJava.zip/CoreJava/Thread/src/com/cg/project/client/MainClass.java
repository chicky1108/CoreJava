package com.cg.project.client;

public class MainClass {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
RunnableResource resource=new RunnableResource();
Thread th1 = new Thread(resource,"tick thread");
Thread th2 = new Thread(resource,"tock thread");
th1.start();
th1.join();
th2.start();

	}

}
