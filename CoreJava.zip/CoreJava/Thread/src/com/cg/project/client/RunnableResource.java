package com.cg.project.client;

public class RunnableResource implements Runnable {

@Override
public void run()
{
	Thread t=Thread.currentThread();
	if(t.getName().equalsIgnoreCase("tickThread"));
	for(int i=1;i<=10;i++)
		System.out.println("Tick      "+i+""+t.getName());
	
	if(t.getName().equalsIgnoreCase("tockThread"));
	for(int i=1;i<=10;i++)
		System.out.println("T0ck      "+i+""+t.getName());
	System.out.println("End of thread task");
	}
}
