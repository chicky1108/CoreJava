package com.cg.payroll.test;

import java.util.ArrayList;
import java.util.Collections;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


import com.cg.payroll.bean.Associate;
import com.cg.payroll.bean.BankDetails;
import com.cg.payroll.bean.Salary;
import com.cg.payroll.exceptions.AssociateDetailNotfoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;

import junit.framework.Assert;

public class PayrollServicesTest {
private static PayrollServices services;
@BeforeClass
public static void setUpTestEnv() {
	services = new PayrollServicesImpl();
	
}
@Before
public void setUpTestData()
{
	Associate associate1 = new Associate(101,69000,"souree","biswasdas","analyst","fresher","abcd405","sbd@gmail", new Salary(50000,500,400),new BankDetails(12345,"axis","1108"));
	Associate associate2 = new Associate(102,96000,"rounak","das","analyst","fresher","absd405","rd@gmail", new Salary(60000,600,500),new BankDetails(12385,"axis","1128"));
PayrollDBUtil.associates.put(associate1.getAssociateId(),associate1);
PayrollDBUtil.associates.put(associate2.getAssociateId(),associate2);
PayrollDBUtil.ASSOCIATE_ID_COUNTER=102;
}
@Test(expected=AssociateDetailNotfoundException.class)
public void testGetAssociateDetailsForInvalidAssociateId() throws AssociateDetailNotfoundException
{
	services.getAssociateDetails(1234);
	}
@Test(expected=AssociateDetailNotfoundException.class)
public void testGetAssociateDetailsForValidAssociateId() throws AssociateDetailNotfoundException
{
	Associate expectedAssociate = new Associate(102,96000,"rounak","das","analyst","fresher","absd405","rd@gmail", new Salary(60000,600,500),new BankDetails(12385,"axis","1128"));
	Associate actualAssociate=services.getAssociateDetails(102);
	Assert.assertEquals(expectedAssociate, actualAssociate);
	}
public void testCalculateNetSalaryForInvalidAssociateId() throws AssociateDetailNotfoundException
{
	services.calculateNetSalary(1234);
	}
@Test
public void testCalculateNetSalaryForValidData() throws AssociateDetailNotfoundException
{
	int expectedId=103;
	int actualId=services.acceptAssociateDetails("rohini", "sinha", "roro@123", "it", "manager", "jkl90", 60000, 901200000, 500, 600, 2000, "icici", "lkio989");
	
	Assert.assertEquals(expectedId, actualId);
	}
@Test
public void testCalculateNetSalaryForValidAssociateId() throws AssociateDetailNotfoundException
{
	int expectedNetSalary=0;
	int actualNetSalary=services.calculateNetSalary(102);
	Assert.assertEquals(expectedNetSalary, actualNetSalary);
	services.calculateNetSalary(1234);
	}
@Test
public void testGetAllAssociateDetails()
{
	Associate associate1 = new Associate(101,69000,"souree","biswasdas","analyst","fresher","abcd405","sbd@gmail", new Salary(50000,500,400),new BankDetails(12345,"axis","1108"));
	Associate associate2 = new Associate(102,96000,"rounak","das","analyst","fresher","absd405","rd@gmail", new Salary(60000,600,500),new BankDetails(12385,"axis","1128"));
	ArrayList<Associate>expectedAssociateList=new ArrayList<>();
	expectedAssociateList.add(associate1);
	expectedAssociateList.add(associate2);
	ArrayList<Associate>actualAssociateList=(ArrayList<Associate>)services.getAllAssociateDetails();
	Collections.sort(expectedAssociateList);
	Collections.sort(actualAssociateList);
	Assert.assertEquals(expectedAssociateList, actualAssociateList);
	}
	@After
	public void tearDownTestData()
	{
		PayrollDBUtil.associates.clear();
		PayrollDBUtil.ASSOCIATE_ID_COUNTER=100;
	}
	@AfterClass
	public static void tearDownTestEnv()
	{
	services=null;	
	}
	}