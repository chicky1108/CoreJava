package com.cg.payroll.test;

import java.util.ArrayList;
import java.util.Collections;

import org.easymock.EasyMock;
import org.junit.*;
import org.junit.Before;
import org.junit.BeforeClass;
import com.cg.payroll.bean.Associate;
import com.cg.payroll.bean.BankDetails;
import com.cg.payroll.bean.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class PayrollServicesTestEasyMock {
private static PayrollServices payrollservices;
private static AssociateDAO mockAssociateDAO;
@BeforeClass
public static void setUpTestEnv()
{
	mockAssociateDAO=EasyMock.mock(AssociateDAO.class);
	payrollservices=new PayrollServicesImpl(mockAssociateDAO);
	}
@Before
public void setUpMockData()
{
	Associate associate1 = new Associate(101,69000,"souree","biswasdas","analyst","fresher","abcd405","sbd@gmail", new Salary(50000,500,400),new BankDetails(12345,"axis","1108"));
	Associate associate2 = new Associate(102,96000,"rounak","das","analyst","fresher","absd405","rd@gmail", new Salary(60000,600,500),new BankDetails(12385,"axis","1128"));
	Associate associate3 = new Associate(103,29000,"ree","biswasdas","analyst","fresher","abd405","tbd@gmail", new Salary(10000,200,300),new BankDetails(1234,"axis","118"));
	ArrayList<Associate>associatesList=new ArrayList<>();
	associatesList.add(associate1);
	associatesList.add(associate2);
	EasyMock.expect(mockAssociateDAO.findOne(101)).andReturn(associate1);
	EasyMock.expect(mockAssociateDAO.findOne(102)).andReturn(associate2);
	EasyMock.expect(mockAssociateDAO.findOne(1234)).andReturn(null);
	EasyMock.expect(mockAssociateDAO.findAll()).andReturn(associatesList);
	EasyMock.replay(mockAssociateDAO);
	

}
}