package com.cg.banking.exception;

public class AccountBlockedException extends Exception{

	public AccountBlockedException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AccountBlockedException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public AccountBlockedException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public AccountBlockedException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public AccountBlockedException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
