package com.cg.payroll.client;

import com.cg.payroll.exceptions.AssociateDetailNotfoundException;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass 
{
	public static void main(String[] args) throws AssociateDetailNotfoundException 
	{
         PayrollServicesImpl services = new PayrollServicesImpl();
         int associateId1 = services.acceptAssociateDetails("Souree", "Biswas", "sbd@gmail.com", "Fresher", "Analyst", "5464",100000, 500000, 21600, 15384, 5464376,"hdfc", "64647");
         System.out.println("Associate Id: " + associateId1);
      
		System.out.println(services.getAssociateDetails(associateId1));
		
		System.out.println(services.calculateNetSalary(associateId1));
		System.out.println(services.updateDetails(associateId1,5000,3000,1000));
	}}