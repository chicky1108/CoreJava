import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

public class MainClass {
	public static void main(String args[])throws FileNotFoundException,IOException,ClassNotFoundException{
		File file =  new File("D:\\souree.txt");
		SerializationDemo.doserialization(file);
		SerializationDemo.doDeserialization(file);
	}

}
