import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringRegex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
m1();
m2();
m3();
m4();
	}
public static void m1()
{
	String str ="Hello Welc34866ome to Jav4a FullStack Training";
	Pattern pattern=Pattern.compile("\\d?");
	Matcher matcher=pattern.matcher(str);
	while(matcher.find())
	{
		System.out.println(matcher.start()+""+matcher.end()+""+matcher.group());
	}
	
	}
public static void m2()
{
	String str ="Hello Welc34866ome to Jav4a FullStack Training";
	Pattern pattern=Pattern.compile("\\d_");
	Matcher matcher=pattern.matcher(str);
	while(matcher.find())
	{
		System.out.println(matcher.start()+""+matcher.end()+""+matcher.group());
	}
	
	}
public static void m3()
{
	String str ="Hello Welc34866ome to Jav4a FullStack Training";
	Pattern pattern=Pattern.compile("\\d$");
	Matcher matcher=pattern.matcher(str);
	while(matcher.find())
	{
		System.out.println(matcher.start()+""+matcher.end()+""+matcher.group());
	}
	
	}
public static void m4()
{
	String str ="Hello Welc34866ome to Jav4a FullStack Training";
	Pattern pattern=Pattern.compile("\\d*");
	Matcher matcher=pattern.matcher(str);
	while(matcher.find())
	{
		System.out.println(matcher.start()+""+matcher.end()+""+matcher.group());
	}
	
	}

}

