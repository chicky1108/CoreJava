import java.io.Serializable;

public class Customer implements  Serializable

{
private static int CUSTOMER_ID_COUNTER=100;

private static int custId;
private String firstName,lastName;
private transient Address address;
public Customer()
{
	
	}
public Customer(int custId,String firstName, String lastName, Address address) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.address = address;
	this.custId = custId;
}
public static int getCUSTOMER_ID_COUNTER() {
	return CUSTOMER_ID_COUNTER;
}
public static void setCUSTOMER_ID_COUNTER(int cUSTOMER_ID_COUNTER) {
	CUSTOMER_ID_COUNTER = cUSTOMER_ID_COUNTER;
}
public static int getCustId() {
	return custId;
}
public static void setCustId(int custId) {
	Customer.custId = custId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}
@Override
public String toString() {
	return "Customer [firstName=" + firstName + ", lastName=" + lastName + ", address=" + address + ",custId="+custId+"]";
}

}
