import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializationDemo {

	public static void doserialization(File file) throws FileNotFoundException,IOException {
		// TODO Auto-generated method stub
try(ObjectOutputStream writer = new ObjectOutputStream(new FileOutputStream(file)))
{
	Customer customer = new Customer(11,"Souree","Rounak",new Address("kolkata","India"));
	writer.writeObject(customer);
	System.out.println("Customer object transferred to:"+file.getAbsolutePath());
	}
	}
	public static void doDeserialization(File file) throws FileNotFoundException,IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
try(ObjectInputStream reader= new ObjectInputStream(new FileInputStream(file)))
{
	Customer customer = (Customer)reader.readObject();
	System.out.println(customer);
	}
	}
	

}
