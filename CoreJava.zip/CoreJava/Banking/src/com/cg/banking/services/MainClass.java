package com.cg.banking.services;

public class MainClass {
public static void main(String args[])
{
	BankingServices services = new BankingServicesImpl();
	int accountNo=services.acceptAssociateDetails(11,"axis","yes",222.8f,22,66.4f,"ytyht");
	System.out.println("accountNo:"+accountNo);
	
	}

}
