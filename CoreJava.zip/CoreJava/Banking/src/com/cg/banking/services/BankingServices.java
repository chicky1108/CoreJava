package com.cg.banking.services;

import java.util.List;
public  interface BankingServices{
	
	Account openAccount(String accountType,float initBalance)
	throws InvalidAmountException,InvalidAccountTypeException,BankingServiceDownException;
	
	
	float depositAmount(long accountNo,float Amount)
			throws AccountNotFoundException,AccountBlockedException,BankingServiceDownException;
	
	float withdrawAmount(long accountNo,float Amount,int pinNumber)
			throws InsufficientAmountException,InvalidPinNumberException,AccountNotFoundException,AccountBlockedException,BankingServiceDownException;

boolean fundTransfer(long accountNo,float amount,int pinNumber)
		throws InsufficientAmountException,InvalidPinNumberException,AccountNotFoundException,AccountBlockedException,BankingServiceDownException;

Account getAccountDetails(long accountNo)
		throws AccountNotFoundException,BankingServiceDownException;

List<Account>getAllAccountDetails()
		throws BankingServiceDownException;

List<Transaction>getAccountAllTransaction(long accountNo)
		throws AccountNotFoundException,BankingServiceDownException;
public String accountStatus(long accountNo)
throws   AccountNotFoundException,BankingServiceDownException,AccountBlockedException;
}