package com.cg.banking.services;

public class BankingServiceDownException extends Exception {

}
