package com.cg.banking.services;



import java.util.HashMap;
import java.util.Random;

public class AccountDBUtil {

	public static HashMap<Long,Account>account = new HashMap<>();
	
	private static int ACCOUNT_NO_COUNTER=100000;

	static Random rand = new Random();
	public static int getASSOCIATE_ID_COUNTER()
	{
		return ++ACCOUNT_NO_COUNTER;
	}
public static long PIN_NUMBER=rand.nextInt();
public static long getPIN_NUMBER()
{
	return PIN_NUMBER;
	}
	}