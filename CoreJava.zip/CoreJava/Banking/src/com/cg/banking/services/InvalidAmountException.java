package com.cg.banking.services;

public class InvalidAmountException extends Exception {

}
