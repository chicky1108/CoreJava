package com.cg.banking.services;


import java.util.List;


public interface AccountDAO
{
Account save(Account account);
boolean update(Account account);
Account findOne(int accountNo);
List<Account>findAll();
}