package com.cg.banking.services;

import java.util.List;

public class AccountDAOImpl implements AccountDAO
{

	@Override
	public Account save(Account account) {
		account.setAccountNo(AccountDBUtil.getASSOCIATE_ID_COUNTER());
		AccountDBUtil.account.put(account.getAccountNo(),account);
		
		return null;
	}

	@Override
	public boolean update(Account account) {
		
		return false;
	}

	@Override
	public Account findOne(int accountNo) {
		
		return null;
	}

	@Override
	public List<Account> findAll() {
		
		return null;
	}

}
