package com.cg.banking.services;


public class Associate 
{

	private int associateId;
    private int yearlyInvestmentUnder80C;
    private String firstName,lastName,department,designation,pancard,emailId;
    private Salary salary;
    private BankDetails bankDetails;
public Associate() 
{
	
}

public Associate(int yearlyInvestmentUnder80C, String firstName, String lastName, String department, String designation,
		String pancard, String emailId, Salary salary, BankDetails bankDetails) {
	super();
	this.yearlyInvestmentUnder80C = yearlyInvestmentUnder80C;
	this.firstName = firstName;
	this.lastName = lastName;
	this.department = department;
	this.designation = designation;
	this.pancard = pancard;
	this.emailId = emailId;
	this.salary = salary;
	this.bankDetails = bankDetails;
}}
