package com.cg.banking.services;

import java.util.List;

public class BankingServicesImpl implements  BankingServices 
{
private AccountDAO accountDao = new AccountDAOImpl();




@Override
public Account openAccount(String accountType, float initBalance)
		throws InvalidAmountException, InvalidAccountTypeException, BankingServiceDownException {
	// TODO Auto-generated method stub
if(initBalance<1000.0f)
{
	throw new InvalidAmountException();
	}
else if(!accountType.contentEquals("current")||!accountType.contentEquals("savings"))
{
throw new 	InvalidAccountTypeException();
}
	Account account = new Account(accountType,initBalance);
	account = accountDao.save(account);
	return account;
}

@Override
public float depositAmount(long accountNo, float Amount)
		throws AccountNotFoundException, AccountBlockedException, BankingServiceDownException {
	// TODO Auto-generated method stub
	return 0;
}

@Override
public float withdrawAmount(long accountNo, float Amount, int pinNumber) throws InsufficientAmountException,
		InvalidPinNumberException, AccountNotFoundException, AccountBlockedException, BankingServiceDownException {
	// TODO Auto-generated method stub
	return 0;
}

@Override
public boolean fundTransfer(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
		InvalidPinNumberException, AccountNotFoundException, AccountBlockedException, BankingServiceDownException {
	// TODO Auto-generated method stub
	return false;
}

@Override
public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServiceDownException {
	// TODO Auto-generated method stub
	return null;
}

@Override
public List<Account> getAllAccountDetails() throws BankingServiceDownException {
	// TODO Auto-generated method stub
	return null;
}

@Override
public List<Transaction> getAccountAllTransaction(long accountNo)
		throws AccountNotFoundException, BankingServiceDownException {
	// TODO Auto-generated method stub
	return null;
}

@Override
public String accountStatus(long accountNo)
		throws AccountNotFoundException, BankingServiceDownException, AccountBlockedException {
	// TODO Auto-generated method stub
	return null;
}

}
