package com.cg.banking.services;

public class InvalidAccountTypeException extends Exception {

}
