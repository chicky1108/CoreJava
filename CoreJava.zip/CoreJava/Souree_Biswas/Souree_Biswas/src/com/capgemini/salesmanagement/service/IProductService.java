package com.capgemini.salesmanagement.service;

import com.capgemini.salesmanagement.bean.Product;
import com.capgemini.takehome.exceptions.InvalidQuantityException;
import com.capgemini.takehome.exceptions.ProductNotFoundException;

public interface IProductService {
	Product getProductDetails(int productCode, int quantityOfProduct)throws InvalidQuantityException,ProductNotFoundException;
}
