package com.capgemini.salesmanagement.bean;

public class Product {
	private int productId;
	private String productName;
	private String productCateogery;
	private int productPrice;
	private int quantity;
	private int lineTotal;
	public Product() {}
	public Product(int productId, String productName, String productCateogery, int productPrice, int quantity,
			int lineTotal) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productCateogery = productCateogery;
		this.productPrice = productPrice;
		this.quantity = quantity;
		this.lineTotal = lineTotal;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getLineTotal() {
		return lineTotal;
	}
	public void setLineTotal(int lineTotal) {
		this.lineTotal = lineTotal;
	}
	public Product(int productId, String productName, String productCateogery, int productPrice) {
		this.productId = productId;
		this.productName = productName;
		this.productCateogery = productCateogery;
		this.productPrice = productPrice;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCateogery() {
		return productCateogery;
	}
	public void setProductCateogery(String productCateogery) {
		this.productCateogery = productCateogery;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	@Override
	public String toString() {
		return "Product \nproductId:" + productId + "\n productName:" + productName + "\n productCateogery:"
				+ productCateogery + "\n productPrice:" + productPrice + "\n quantity:" + quantity + "\n lineTotal:"
				+ lineTotal ;
	}
	
	
}
