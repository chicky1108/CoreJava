package com.capgemini.bill.daoservices;

import com.capgemini.salesmanagement.bean.Product;

public interface IProductDAO {
	Product getProductDetails(int productCode);
}
