package com.capgemini.bill.daoservices;

import com.capgemini.bill.util.CollectionUtil;
import com.capgemini.salesmanagement.bean.Product;

public class ProductDAO implements IProductDAO{
	@Override
	public Product getProductDetails(int productCode) {
		Product product = CollectionUtil.products.get(productCode);
		return product;
	}

}
