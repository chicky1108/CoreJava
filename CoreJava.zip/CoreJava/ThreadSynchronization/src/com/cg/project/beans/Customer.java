package com.cg.project.beans;

public class Customer  implements Runnable{
	public Customer()
	{
		
	}
	private static Account account;
	static
	{
		account = new Account(1000);
		System.out.println("Initial balance:-"+account.getBalance()+"\n\n==============");
	}
@Override
public void run() {
	Thread customerThread=Thread.currentThread();
	if(customerThread.getName().equals("rounak"))
	{
		for(int i=0;i<10;i++)
		{
			try
			{
				System.out.println("\nRounak has call withdraw()"+i+"time balance="+account.withdraw(3000));
				Thread.sleep(2000);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
			
		}
	}
	if(customerThread.getName().equals("souree"))
	{
		for(int i=0;i<10;i++)
		{
			try
			{
				System.out.println("\nsouree has call deposit()"+i+"time balance="+account.deposit(2000));
				Thread.sleep(2000);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
			
		}
	}
	else if(customerThread.getName().equals("sou")){
		for(int i=1;i<=3;i++)
		{
			System.out.println("\nsou has call deposit()"+i+"time balance="+account.checkBalnce());
		}
	}
	{
		
	}
}
}
