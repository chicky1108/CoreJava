package com.cg.project.beans;

public class Main {
public static void main (String[] args)
{
	Thread th1=new Thread(new Customer(),"rounak");
	Thread th2=new Thread(new Customer(),"souree");
	Thread th3=new Thread(new Customer(),"sou");
	th1.start();
	th1.setPriority(Thread.MAX_PRIORITY);
	th2.start();
	th3.start();
	}
}
