package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.banking.DBUtil.BankingServicesDBUtil;
import com.cg.banking.beans.Account;

public class AccountDAOImpl implements AccountDAO{
	@Override
	public Account save(Account account) {
		account.setAccountNo(BankingServicesDBUtil.setACCOUNT_NO());
		account.setPinNumber(BankingServicesDBUtil.setPIN_NO());
		account.setAccountStatus(BankingServicesDBUtil.setSETACCOUNT_STATUS());
		BankingServicesDBUtil.accountDetails.put(account.getAccountNo(),account);
		return account;
	}

	@Override
	public boolean update(Account account) {
		return true;
	}

	@Override
	public Account findOne(long accountNo) {
		 Account account =BankingServicesDBUtil.accountDetails.get(accountNo);
		return account;
	}

	@Override
	public List<Account> findAll() {
		ArrayList<Account> accountDetails=new ArrayList<>(BankingServicesDBUtil.accountDetails.values());
		return accountDetails;
	}

}
