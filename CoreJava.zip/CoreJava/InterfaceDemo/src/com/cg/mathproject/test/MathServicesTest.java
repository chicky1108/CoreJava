package com.cg.mathproject.test;
import  org.junit.AfterClass;
import org.junit.BeforeClass;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.mathproject.exceptions.NegativeNumberException;
import com.cg.mathproject.services.MathServices;
import com.cg.mathproject.services.MathServicesImpl;

import junit.framework.Assert;

public class MathServicesTest {
private static MathServices services;
@BeforeClass
	public static void setUpTestEnv() {
		services = new MathServicesImpl();
		
	}
	@Test(expected=NegativeNumberException.class)
	public void testAddForFirstNumberInvalid()throws NegativeNumberException{
		services.add(-100,200);
	} 
	@Test(expected=NegativeNumberException.class)
	public void testAddForSecondNumberInvalid()throws NegativeNumberException{
		services.add(100,-200);
	}
@Test
public void testAddForBothValidNumber()throws NegativeNumberException{
	Assert.assertEquals(300,services.add(100,200));
}
@AfterClass
public static void tearDownTestEnv() {
	services=null;
}
}
