
public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Employee e1 = new Employee();
Employee e2 = new Employee();
e1.setEmpId(11);
e1.setFirstName("Souree");
e1.setLastName("BiswasDas");
e1.setSalary(80000.0);

e2.setEmpId(11);
e2.setFirstName("Souree");
e2.setLastName("BiswasDas");
e2.setSalary(80000.0);
if(e1==e2)
{
	System.out.println("Same");
	}
else {
	System.out.println("Not Same");
}
if(e1.equals(e2))
{
	System.out.println("Same data");
	}
else {
	System.out.println("Not Same data");
}
	}

}
